# Wiki Archive
## With wiki archive, you can easily:
* Save historical copies of flask/markdown pages
* Restore a page to it's original content
